var b = { exports: {} }, j = b.exports, M;
function O() {
  return M || (M = 1, (function(R, q) {
    (function(h, w) {
      w(R);
    })(typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : j, function(h) {
      if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id))
        throw new Error("This script should only be loaded in a browser extension.");
      if (globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)
        h.exports = globalThis.browser;
      else {
        const w = "The message port closed before a response was received.", N = (l) => {
          const k = {
            alarms: {
              clear: {
                minArgs: 0,
                maxArgs: 1
              },
              clearAll: {
                minArgs: 0,
                maxArgs: 0
              },
              get: {
                minArgs: 0,
                maxArgs: 1
              },
              getAll: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            bookmarks: {
              create: {
                minArgs: 1,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              getChildren: {
                minArgs: 1,
                maxArgs: 1
              },
              getRecent: {
                minArgs: 1,
                maxArgs: 1
              },
              getSubTree: {
                minArgs: 1,
                maxArgs: 1
              },
              getTree: {
                minArgs: 0,
                maxArgs: 0
              },
              move: {
                minArgs: 2,
                maxArgs: 2
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              removeTree: {
                minArgs: 1,
                maxArgs: 1
              },
              search: {
                minArgs: 1,
                maxArgs: 1
              },
              update: {
                minArgs: 2,
                maxArgs: 2
              }
            },
            browserAction: {
              disable: {
                minArgs: 0,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              enable: {
                minArgs: 0,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              getBadgeBackgroundColor: {
                minArgs: 1,
                maxArgs: 1
              },
              getBadgeText: {
                minArgs: 1,
                maxArgs: 1
              },
              getPopup: {
                minArgs: 1,
                maxArgs: 1
              },
              getTitle: {
                minArgs: 1,
                maxArgs: 1
              },
              openPopup: {
                minArgs: 0,
                maxArgs: 0
              },
              setBadgeBackgroundColor: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setBadgeText: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setIcon: {
                minArgs: 1,
                maxArgs: 1
              },
              setPopup: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setTitle: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              }
            },
            browsingData: {
              remove: {
                minArgs: 2,
                maxArgs: 2
              },
              removeCache: {
                minArgs: 1,
                maxArgs: 1
              },
              removeCookies: {
                minArgs: 1,
                maxArgs: 1
              },
              removeDownloads: {
                minArgs: 1,
                maxArgs: 1
              },
              removeFormData: {
                minArgs: 1,
                maxArgs: 1
              },
              removeHistory: {
                minArgs: 1,
                maxArgs: 1
              },
              removeLocalStorage: {
                minArgs: 1,
                maxArgs: 1
              },
              removePasswords: {
                minArgs: 1,
                maxArgs: 1
              },
              removePluginData: {
                minArgs: 1,
                maxArgs: 1
              },
              settings: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            commands: {
              getAll: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            contextMenus: {
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              removeAll: {
                minArgs: 0,
                maxArgs: 0
              },
              update: {
                minArgs: 2,
                maxArgs: 2
              }
            },
            cookies: {
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              getAll: {
                minArgs: 1,
                maxArgs: 1
              },
              getAllCookieStores: {
                minArgs: 0,
                maxArgs: 0
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              set: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            devtools: {
              inspectedWindow: {
                eval: {
                  minArgs: 1,
                  maxArgs: 2,
                  singleCallbackArg: !1
                }
              },
              panels: {
                create: {
                  minArgs: 3,
                  maxArgs: 3,
                  singleCallbackArg: !0
                },
                elements: {
                  createSidebarPane: {
                    minArgs: 1,
                    maxArgs: 1
                  }
                }
              }
            },
            downloads: {
              cancel: {
                minArgs: 1,
                maxArgs: 1
              },
              download: {
                minArgs: 1,
                maxArgs: 1
              },
              erase: {
                minArgs: 1,
                maxArgs: 1
              },
              getFileIcon: {
                minArgs: 1,
                maxArgs: 2
              },
              open: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              pause: {
                minArgs: 1,
                maxArgs: 1
              },
              removeFile: {
                minArgs: 1,
                maxArgs: 1
              },
              resume: {
                minArgs: 1,
                maxArgs: 1
              },
              search: {
                minArgs: 1,
                maxArgs: 1
              },
              show: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              }
            },
            extension: {
              isAllowedFileSchemeAccess: {
                minArgs: 0,
                maxArgs: 0
              },
              isAllowedIncognitoAccess: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            history: {
              addUrl: {
                minArgs: 1,
                maxArgs: 1
              },
              deleteAll: {
                minArgs: 0,
                maxArgs: 0
              },
              deleteRange: {
                minArgs: 1,
                maxArgs: 1
              },
              deleteUrl: {
                minArgs: 1,
                maxArgs: 1
              },
              getVisits: {
                minArgs: 1,
                maxArgs: 1
              },
              search: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            i18n: {
              detectLanguage: {
                minArgs: 1,
                maxArgs: 1
              },
              getAcceptLanguages: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            identity: {
              launchWebAuthFlow: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            idle: {
              queryState: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            management: {
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              getAll: {
                minArgs: 0,
                maxArgs: 0
              },
              getSelf: {
                minArgs: 0,
                maxArgs: 0
              },
              setEnabled: {
                minArgs: 2,
                maxArgs: 2
              },
              uninstallSelf: {
                minArgs: 0,
                maxArgs: 1
              }
            },
            notifications: {
              clear: {
                minArgs: 1,
                maxArgs: 1
              },
              create: {
                minArgs: 1,
                maxArgs: 2
              },
              getAll: {
                minArgs: 0,
                maxArgs: 0
              },
              getPermissionLevel: {
                minArgs: 0,
                maxArgs: 0
              },
              update: {
                minArgs: 2,
                maxArgs: 2
              }
            },
            pageAction: {
              getPopup: {
                minArgs: 1,
                maxArgs: 1
              },
              getTitle: {
                minArgs: 1,
                maxArgs: 1
              },
              hide: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setIcon: {
                minArgs: 1,
                maxArgs: 1
              },
              setPopup: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              setTitle: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              },
              show: {
                minArgs: 1,
                maxArgs: 1,
                fallbackToNoCallback: !0
              }
            },
            permissions: {
              contains: {
                minArgs: 1,
                maxArgs: 1
              },
              getAll: {
                minArgs: 0,
                maxArgs: 0
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              request: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            runtime: {
              getBackgroundPage: {
                minArgs: 0,
                maxArgs: 0
              },
              getPlatformInfo: {
                minArgs: 0,
                maxArgs: 0
              },
              openOptionsPage: {
                minArgs: 0,
                maxArgs: 0
              },
              requestUpdateCheck: {
                minArgs: 0,
                maxArgs: 0
              },
              sendMessage: {
                minArgs: 1,
                maxArgs: 3
              },
              sendNativeMessage: {
                minArgs: 2,
                maxArgs: 2
              },
              setUninstallURL: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            sessions: {
              getDevices: {
                minArgs: 0,
                maxArgs: 1
              },
              getRecentlyClosed: {
                minArgs: 0,
                maxArgs: 1
              },
              restore: {
                minArgs: 0,
                maxArgs: 1
              }
            },
            storage: {
              local: {
                clear: {
                  minArgs: 0,
                  maxArgs: 0
                },
                get: {
                  minArgs: 0,
                  maxArgs: 1
                },
                getBytesInUse: {
                  minArgs: 0,
                  maxArgs: 1
                },
                remove: {
                  minArgs: 1,
                  maxArgs: 1
                },
                set: {
                  minArgs: 1,
                  maxArgs: 1
                }
              },
              managed: {
                get: {
                  minArgs: 0,
                  maxArgs: 1
                },
                getBytesInUse: {
                  minArgs: 0,
                  maxArgs: 1
                }
              },
              sync: {
                clear: {
                  minArgs: 0,
                  maxArgs: 0
                },
                get: {
                  minArgs: 0,
                  maxArgs: 1
                },
                getBytesInUse: {
                  minArgs: 0,
                  maxArgs: 1
                },
                remove: {
                  minArgs: 1,
                  maxArgs: 1
                },
                set: {
                  minArgs: 1,
                  maxArgs: 1
                }
              }
            },
            tabs: {
              captureVisibleTab: {
                minArgs: 0,
                maxArgs: 2
              },
              create: {
                minArgs: 1,
                maxArgs: 1
              },
              detectLanguage: {
                minArgs: 0,
                maxArgs: 1
              },
              discard: {
                minArgs: 0,
                maxArgs: 1
              },
              duplicate: {
                minArgs: 1,
                maxArgs: 1
              },
              executeScript: {
                minArgs: 1,
                maxArgs: 2
              },
              get: {
                minArgs: 1,
                maxArgs: 1
              },
              getCurrent: {
                minArgs: 0,
                maxArgs: 0
              },
              getZoom: {
                minArgs: 0,
                maxArgs: 1
              },
              getZoomSettings: {
                minArgs: 0,
                maxArgs: 1
              },
              goBack: {
                minArgs: 0,
                maxArgs: 1
              },
              goForward: {
                minArgs: 0,
                maxArgs: 1
              },
              highlight: {
                minArgs: 1,
                maxArgs: 1
              },
              insertCSS: {
                minArgs: 1,
                maxArgs: 2
              },
              move: {
                minArgs: 2,
                maxArgs: 2
              },
              query: {
                minArgs: 1,
                maxArgs: 1
              },
              reload: {
                minArgs: 0,
                maxArgs: 2
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              removeCSS: {
                minArgs: 1,
                maxArgs: 2
              },
              sendMessage: {
                minArgs: 2,
                maxArgs: 3
              },
              setZoom: {
                minArgs: 1,
                maxArgs: 2
              },
              setZoomSettings: {
                minArgs: 1,
                maxArgs: 2
              },
              update: {
                minArgs: 1,
                maxArgs: 2
              }
            },
            topSites: {
              get: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            webNavigation: {
              getAllFrames: {
                minArgs: 1,
                maxArgs: 1
              },
              getFrame: {
                minArgs: 1,
                maxArgs: 1
              }
            },
            webRequest: {
              handlerBehaviorChanged: {
                minArgs: 0,
                maxArgs: 0
              }
            },
            windows: {
              create: {
                minArgs: 0,
                maxArgs: 1
              },
              get: {
                minArgs: 1,
                maxArgs: 2
              },
              getAll: {
                minArgs: 0,
                maxArgs: 1
              },
              getCurrent: {
                minArgs: 0,
                maxArgs: 1
              },
              getLastFocused: {
                minArgs: 0,
                maxArgs: 1
              },
              remove: {
                minArgs: 1,
                maxArgs: 1
              },
              update: {
                minArgs: 2,
                maxArgs: 2
              }
            }
          };
          if (Object.keys(k).length === 0)
            throw new Error("api-metadata.json has not been included in browser-polyfill");
          class C extends WeakMap {
            constructor(r, g = void 0) {
              super(g), this.createItem = r;
            }
            get(r) {
              return this.has(r) || this.set(r, this.createItem(r)), super.get(r);
            }
          }
          const $ = (e) => e && typeof e == "object" && typeof e.then == "function", v = (e, r) => (...g) => {
            l.runtime.lastError ? e.reject(new Error(l.runtime.lastError.message)) : r.singleCallbackArg || g.length <= 1 && r.singleCallbackArg !== !1 ? e.resolve(g[0]) : e.resolve(g);
          }, u = (e) => e == 1 ? "argument" : "arguments", F = (e, r) => function(n, ...a) {
            if (a.length < r.minArgs)
              throw new Error(`Expected at least ${r.minArgs} ${u(r.minArgs)} for ${e}(), got ${a.length}`);
            if (a.length > r.maxArgs)
              throw new Error(`Expected at most ${r.maxArgs} ${u(r.maxArgs)} for ${e}(), got ${a.length}`);
            return new Promise((i, t) => {
              if (r.fallbackToNoCallback)
                try {
                  n[e](...a, v({
                    resolve: i,
                    reject: t
                  }, r));
                } catch (s) {
                  console.warn(`${e} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, s), n[e](...a), r.fallbackToNoCallback = !1, r.noCallback = !0, i();
                }
              else r.noCallback ? (n[e](...a), i()) : n[e](...a, v({
                resolve: i,
                reject: t
              }, r));
            });
          }, E = (e, r, g) => new Proxy(r, {
            apply(n, a, i) {
              return g.call(a, e, ...i);
            }
          });
          let f = Function.call.bind(Object.prototype.hasOwnProperty);
          const d = (e, r = {}, g = {}) => {
            let n = /* @__PURE__ */ Object.create(null), a = {
              has(t, s) {
                return s in e || s in n;
              },
              get(t, s, A) {
                if (s in n)
                  return n[s];
                if (!(s in e))
                  return;
                let m = e[s];
                if (typeof m == "function")
                  if (typeof r[s] == "function")
                    m = E(e, e[s], r[s]);
                  else if (f(g, s)) {
                    let c = F(s, g[s]);
                    m = E(e, e[s], c);
                  } else
                    m = m.bind(e);
                else if (typeof m == "object" && m !== null && (f(r, s) || f(g, s)))
                  m = d(m, r[s], g[s]);
                else if (f(g, "*"))
                  m = d(m, r[s], g["*"]);
                else
                  return Object.defineProperty(n, s, {
                    configurable: !0,
                    enumerable: !0,
                    get() {
                      return e[s];
                    },
                    set(c) {
                      e[s] = c;
                    }
                  }), m;
                return n[s] = m, m;
              },
              set(t, s, A, m) {
                return s in n ? n[s] = A : e[s] = A, !0;
              },
              defineProperty(t, s, A) {
                return Reflect.defineProperty(n, s, A);
              },
              deleteProperty(t, s) {
                return Reflect.deleteProperty(n, s);
              }
            }, i = Object.create(e);
            return new Proxy(i, a);
          }, p = (e) => ({
            addListener(r, g, ...n) {
              r.addListener(e.get(g), ...n);
            },
            hasListener(r, g) {
              return r.hasListener(e.get(g));
            },
            removeListener(r, g) {
              r.removeListener(e.get(g));
            }
          }), B = new C((e) => typeof e != "function" ? e : function(g) {
            const n = d(g, {}, {
              getContent: {
                minArgs: 0,
                maxArgs: 0
              }
            });
            e(n);
          }), P = new C((e) => typeof e != "function" ? e : function(g, n, a) {
            let i = !1, t, s = new Promise((x) => {
              t = function(o) {
                i = !0, x(o);
              };
            }), A;
            try {
              A = e(g, n, t);
            } catch (x) {
              A = Promise.reject(x);
            }
            const m = A !== !0 && $(A);
            if (A !== !0 && !m && !i)
              return !1;
            const c = (x) => {
              x.then((o) => {
                a(o);
              }, (o) => {
                let T;
                o && (o instanceof Error || typeof o.message == "string") ? T = o.message : T = "An unexpected error occurred", a({
                  __mozWebExtensionPolyfillReject__: !0,
                  message: T
                });
              }).catch((o) => {
                console.error("Failed to send onMessage rejected reply", o);
              });
            };
            return c(m ? A : s), !0;
          }), L = ({
            reject: e,
            resolve: r
          }, g) => {
            l.runtime.lastError ? l.runtime.lastError.message === w ? r() : e(new Error(l.runtime.lastError.message)) : g && g.__mozWebExtensionPolyfillReject__ ? e(new Error(g.message)) : r(g);
          }, S = (e, r, g, ...n) => {
            if (n.length < r.minArgs)
              throw new Error(`Expected at least ${r.minArgs} ${u(r.minArgs)} for ${e}(), got ${n.length}`);
            if (n.length > r.maxArgs)
              throw new Error(`Expected at most ${r.maxArgs} ${u(r.maxArgs)} for ${e}(), got ${n.length}`);
            return new Promise((a, i) => {
              const t = L.bind(null, {
                resolve: a,
                reject: i
              });
              n.push(t), g.sendMessage(...n);
            });
          }, _ = {
            devtools: {
              network: {
                onRequestFinished: p(B)
              }
            },
            runtime: {
              onMessage: p(P),
              onMessageExternal: p(P),
              sendMessage: S.bind(null, "sendMessage", {
                minArgs: 1,
                maxArgs: 3
              })
            },
            tabs: {
              sendMessage: S.bind(null, "sendMessage", {
                minArgs: 2,
                maxArgs: 3
              })
            }
          }, y = {
            clear: {
              minArgs: 1,
              maxArgs: 1
            },
            get: {
              minArgs: 1,
              maxArgs: 1
            },
            set: {
              minArgs: 1,
              maxArgs: 1
            }
          };
          return k.privacy = {
            network: {
              "*": y
            },
            services: {
              "*": y
            },
            websites: {
              "*": y
            }
          }, d(l, _, k);
        };
        h.exports = N(chrome);
      }
    });
  })(b)), b.exports;
}
O();
